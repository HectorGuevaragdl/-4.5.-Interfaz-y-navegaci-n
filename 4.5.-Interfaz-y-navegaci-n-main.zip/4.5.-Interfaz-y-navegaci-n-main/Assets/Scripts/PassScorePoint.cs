using UnityEngine;

public class Pass : MonoBehaviour
{

    private void OnTriggerEnter(Collider other)
    {
        GameManager.singleton.AddScore(1);
    }












}
